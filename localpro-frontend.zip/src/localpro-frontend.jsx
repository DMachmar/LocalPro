import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';

export default function LocalProApp() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [loginData, setLoginData] = useState({ correo: '', password: '' });
  const [registerData, setRegisterData] = useState({ nombre: '', correo: '', password: '', tipo: 'usuario' });
  const [userProfile, setUserProfile] = useState({ nombre: '', correo: '', tipo: 'usuario' });
  const [profProfile, setProfProfile] = useState({ nombre: '', correo: '', rating: 0 });
  const [resenas, setResenas] = useState([]);
  const [chat, setChat] = useState('');
  const [messages, setMessages] = useState([]);
  const [servicios, setServicios] = useState([]);
  const [activeTab, setActiveTab] = useState('usuario');

  const handleLogin = () => {
    fetch('http://localhost:8000/usuarios/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(loginData)
    })
      .then(res => res.json())
      .then(data => {
        setUserProfile(data);
        setLoggedIn(true);
        setActiveTab(data.tipo === 'profesional' ? 'profesional' : 'usuario');
        fetch('http://localhost:8000/profesionales/1')
          .then(res => res.json())
          .then(data => setProfProfile(data));
        fetch('http://localhost:8000/resenas')
          .then(res => res.json())
          .then(data => setResenas(data));
        fetch('http://localhost:8000/servisios')
          .then(res => res.json())
          .then(data => setServicios(data));
      });
  };

  const handleRegister = () => {
    fetch('http://localhost:8000/usuarios/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(registerData)
    })
      .then(res => res.json())
      .then(data => {
        alert('Registro exitoso');
        setIsRegistering(false);
        setLoginData({ correo: registerData.correo, password: registerData.password });
      });
  };

  const handleSendMessage = () => {
    if (chat.trim()) {
      setMessages([...messages, { text: chat, from: 'usuario' }]);
      setChat('');
    }
  };

  if (!loggedIn) {
    return (
      <main className="p-6 max-w-md mx-auto">
        <Card>
          <CardContent className="space-y-4">
            <h1 className="text-xl font-bold">{isRegistering ? 'Registrarse' : 'Iniciar Sesión'}</h1>
            {isRegistering ? (
              <>
                <Input placeholder="Nombre" value={registerData.nombre} onChange={e => setRegisterData({...registerData, nombre: e.target.value})} />
                <Input placeholder="Correo" value={registerData.correo} onChange={e => setRegisterData({...registerData, correo: e.target.value})} />
                <Input placeholder="Contraseña" type="password" value={registerData.password} onChange={e => setRegisterData({...registerData, password: e.target.value})} />
                <Button onClick={handleRegister}>Registrar</Button>
                <p className="text-sm text-center cursor-pointer text-blue-600" onClick={() => setIsRegistering(false)}>¿Ya tienes cuenta? Inicia sesión</p>
              </>
            ) : (
              <>
                <Input placeholder="Correo" value={loginData.correo} onChange={e => setLoginData({...loginData, correo: e.target.value})} />
                <Input placeholder="Contraseña" type="password" value={loginData.password} onChange={e => setLoginData({...loginData, password: e.target.value})} />
                <Button onClick={handleLogin}>Ingresar</Button>
                <p className="text-sm text-center cursor-pointer text-blue-600" onClick={() => setIsRegistering(true)}>¿No tienes cuenta? Regístrate</p>
              </>
            )}
          </CardContent>
        </Card>
      </main>
    );
  }

  return (
    <main className="p-6">
      <h1 className="text-3xl font-bold mb-6">Panel LocalPro</h1>
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="usuario">Usuario</TabsTrigger>
          <TabsTrigger value="profesional">Profesional</TabsTrigger>
        </TabsList>

        <TabsContent value="usuario">
          <Card className="mt-4">
            <CardContent>
              <h2 className="text-xl font-semibold mb-4">Perfil del Usuario</h2>
              <div className="space-y-4">
                <Input placeholder="Nombre" value={userProfile.nombre} onChange={e => setUserProfile({...userProfile, nombre: e.target.value})} />
                <Input placeholder="Correo" value={userProfile.correo} onChange={e => setUserProfile({...userProfile, correo: e.target.value})} />
                <Button>Guardar Cambios</Button>
              </div>

              <div className="mt-6">
                <h3 className="text-lg font-semibold">Servicios Disponibles</h3>
                <ul className="list-disc list-inside">
                  {servicios.map((s, idx) => (
                    <li key={idx}>{s.nombre} — ${s.precio}</li>
                  ))}
                </ul>
              </div>

              <div className="mt-6">
                <h3 className="text-lg font-semibold">Chat Privado</h3>
                <div className="h-40 border p-2 mb-2 overflow-y-auto bg-gray-100">
                  {messages.map((msg, idx) => (
                    <p key={idx} className={msg.from === 'usuario' ? 'text-right' : 'text-left'}>
                      <span className="inline-block p-1 bg-white rounded shadow">{msg.text}</span>
                    </p>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Input placeholder="Escribe un mensaje..." value={chat} onChange={e => setChat(e.target.value)} />
                  <Button onClick={handleSendMessage}>Enviar</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="profesional">
          <Card className="mt-4">
            <CardContent>
              <h2 className="text-xl font-semibold mb-4">Perfil del Profesional</h2>
              <div className="space-y-4">
                <Input placeholder="Nombre" value={profProfile.nombre} onChange={e => setProfProfile({...profProfile, nombre: e.target.value})} />
                <Input placeholder="Correo" value={profProfile.correo} onChange={e => setProfProfile({...profProfile, correo: e.target.value})} />
                <p className="text-sm">Calificación: {profProfile.rating} ⭐</p>
                <Button>Guardar Cambios</Button>
              </div>

              <div className="mt-6">
                <h3 className="text-lg font-semibold">Reseñas Recibidas</h3>
                <ul className="list-disc list-inside">
                  {resenas.map((r, idx) => (
                    <li key={idx} className="text-sm">{r.comentario} — ⭐ {r.puntaje}</li>
                  ))}
                </ul>
              </div>

              <div className="mt-6">
                <h3 className="text-lg font-semibold">Servicios Ofrecidos</h3>
                <ul className="list-disc list-inside">
                  {servicios.map((s, idx) => (
                    <li key={idx}>{s.nombre} — ${s.precio}</li>
                  ))}
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </main>
  );
}
